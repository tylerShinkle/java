//Tyler Shinkle ITDEV 110-002 Assignment #10 Guess The Word 
package shinkle_guesstheword;

import javax.sound.sampled.*;


public class Sound 
{
    public float SAMPLE_RATE = 44100f;
    
    public void tone (double hz, int ms) throws LineUnavailableException
    {
        tone(hz,ms,2);
    }
    
    public void tone(double hz, int ms, double vol)throws LineUnavailableException
    {
        byte[] buf = new byte[2];
        AudioFormat af = 
        new AudioFormat
        (
            SAMPLE_RATE,    //how many samples a sec
            16,             //how much info in a sample
            1,
            true,
            false
        );
        SourceDataLine sdl = AudioSystem.getSourceDataLine(af);
        sdl.open(af);
        sdl.start();

        //number of overtones.
        int size=16;
        double decay = 128;
        double currentAngle=0;
        double reverb=ms*16;
        double fade=0;
        double fadePoint=0;
        //create a 16 bit sample for each ms.
        for(int i=1; i<(ms*16)+1; i++)
        {
        
            fadePoint=Math.round(.80*(ms*16));
            
            //strings lose frequency over time
            if(i%2==0)
            {
                hz-=0.0000001;
            }


            //additional overtones when the string is first hit, then fade
            if(i<100)
            {
                size=32;
            }
            else
            {
                size=16;
            }
   
            //array to hold angles of overtones
            double[] angles = new double[size];

            //holds sum of sins
            double angleSum=0;

            //get angles 
            for(int j=1;j<size+1;j+=2)
            {
                angles[j]=(double)(i/(SAMPLE_RATE /((hz*j))) * 2.0 * Math.PI);
            }
           
            //sum sins of angles 
            for(int k=1;k<size+1;k+=2)
            {
                currentAngle=angles[k];
                if(k==1)
                {
                    if(i%2==0 || i>(.9*ms))
                    {
                        angleSum+=Math.sin(currentAngle);
                    }
                    else if (i%3==0)
                    {
                        angleSum+=Math.sin(currentAngle)*2;
                    }
                    else
                    {
                        angleSum+=Math.sin(currentAngle)*4;
                    }
                    
                }
                else if(k!=7)
                {
                    angleSum+=Math.sin(currentAngle);
                 }
            }
             
            //set final Sin to fluctuiate with time
            /*
            <<cool possible synths>>
            angleSum=Math.sin(Math.sin(angleSum*reverb/(ms*750)))*Math.sin(reverb*10);  
            angleSum=Math.sin(Math.sin(angleSum*reverb/(ms*750)))/reverb*i;
            */
            angleSum=Math.sin(Math.sin(angleSum*reverb/(ms*750)));
            
            //add intensity of initial strike 
            if(i<50)
            {
                vol+=.0125;
            }

            //return after strike
            if(i>50&&i<100)
            {
                vol-=.0125;
            }
            
            //reverb, loss of energy.
            if(i%2==0)
            {
                reverb-=12+(2*(i/1000000));
            }
            else
            {
                reverb+=10-(i/1000000);
            }

            if(i>fadePoint)
            {
                vol*=0.75;
            }
            
                
            buf[0] = (byte)(angleSum * decay * vol);
            buf[1] = (byte)(angleSum * decay * vol);
            sdl.write(buf,0,2);
        }
        sdl.drain();
        sdl.stop();
        sdl.close();
    }

    //write tone methods here...
    public void intro()throws LineUnavailableException
    {
 
        tone(220,2000);
        tone(293,1000);
        tone(349,1000);
    }
    
}
