//Tyler Shinkle ITDEV 110-002 Assignment #10 Guess The Word
package shinkle_guesstheword;

import javax.sound.sampled.LineUnavailableException;

public class Shinkle_GuessTheWord 
{
    //DECLARATIONS BEGIN
    static View ui = new View();
    static boolean run = true;
    //DECLARATIONS END
    

    public static void main(String[] args) throws LineUnavailableException
    {
        ui.intro();
    }

}
