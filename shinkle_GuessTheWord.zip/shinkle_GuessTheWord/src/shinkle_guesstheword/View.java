//Tyler Shinkle ITDEV 110-002 Assignment #10 Guess The Word
package shinkle_guesstheword;

import javax.sound.sampled.LineUnavailableException;

public class View {
    
    //DECLARATIONS BEGIN
    static Sound sound = new Sound();
    //a string of 60 stars.
    public static String stars = String.format("%-60s","\t*").replace(' ','*');
    //DECLARATIONS END

    //output stars for borders
    public static void stars()
    {
        System.out.println(stars);
    }

    //output introduction
    public static void intro()throws LineUnavailableException
    {
        stars();
        checkOutput("AUTHOR: Tyler Shinkle");
        checkOutput("APPLICATION NAME: Guess The Word");
        checkOutput("CLASS: ITDEV 110-002");
        checkOutput("ASSIGNMENT: #10");
        checkOutput("DESCRIPTION:This game is very similar to hangman. First a word will be randomly chosen from an array of words. Then a blank template will be displayed representing the selected word with one _ character representing each letter. The user will then be prompted to guess a letter. If the letter is in the word a pleasant sound will chime and the new template will be displayed replacing the blanks with whichever letter they selected. If the user guesses a letter which is not in the word a unpleasant noise will chime and they will be notified. All letter guesses will be displayed afterwards along with the current template. After each guess the user will be prompted to guess the word. If the user correctly guesses the word a pleasent noise will chime and they will be informed of their victory. There will be a total of 7 turn cycles like this until the game ends. Once a round is complete they will be asked whether they want to play again or quit. If at any time the user passes 'quit' as input the application will exit, for this reason 'quit' will never be the mystery word.");
        stars();
        for(int i=0; i<2; i++)
        {
            sound.intro();
        }
    }

    //METHODS TO FORMAT OUTPUT
    //method to create substrings when strings are longer than our frame.
    public static void checkOutput(String s)
    {
        String subString;
        int currentEnd=55;
        while(s.length()>55)
        {
            //make sure to create substrings on spaces
            while(s.charAt(currentEnd-1)!=' ')
            {
                currentEnd--;
            }
            subString=s.substring(0,currentEnd);
            s=s.substring(currentEnd);
            formatOutput(subString);
            currentEnd=55;
        }
        formatOutput(s);
    }
    
    //method to format output for our frame.
    public static void formatOutput(String s)
    {
        if(s.charAt(0)==' ')
        {
            s=s.substring(1);
        }
        s="\t* "+s;
        s=String.format("%-58s",s)+" *";
        System.out.println(s);
    }

}
